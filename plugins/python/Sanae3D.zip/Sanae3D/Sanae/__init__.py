from Sanae3D.Sanae.SanaeObject import SanaeObject
